//
//  ViewController.swift
//  Applovin-mediation-sample
//
//  Created by Volodymyr Novikov on 21.06.2022.
//

import UIKit
import LoopMeUnitedSDK
import AppLovinSDK

class ViewController: UIViewController, MAAdDelegate {
    func didLoad(_ ad: MAAd) {
    }
    
    func didFailToLoadAd(forAdUnitIdentifier adUnitIdentifier: String, withError error: MAError) {
    }
    
    func didDisplay(_ ad: MAAd) {
    }
    
    func didHide(_ ad: MAAd) {
    }
    
    func didClick(_ ad: MAAd) {
    }
    
    func didFail(toDisplay ad: MAAd, withError error: MAError) {
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        ALSdk.shared()!.initializeSdk { (configuration: ALSdkConfiguration) in
            //LoopMeSDK.shared().initSDK(fromRootViewController: self, completionBlock: nil)
            
        }
        
    }
    
    
}

