//
//  ApplovinInter.h
//  Applovin-mediation-sample
//
//  Created by Volodymyr Novikov on 22.06.2022.
//

#ifndef ApplovinInter_h
#define ApplovinInter_h

@interface ApplovinInter: NSObject
+ (void) loadAd:controller;
@end




#endif /* ApplovinInter_h */
